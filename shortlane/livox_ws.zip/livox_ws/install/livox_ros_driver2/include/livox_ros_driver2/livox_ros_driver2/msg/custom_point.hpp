// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef LIVOX_ROS_DRIVER2__MSG__CUSTOM_POINT_HPP_
#define LIVOX_ROS_DRIVER2__MSG__CUSTOM_POINT_HPP_

#include "livox_ros_driver2/msg/detail/custom_point__struct.hpp"
#include "livox_ros_driver2/msg/detail/custom_point__builder.hpp"
#include "livox_ros_driver2/msg/detail/custom_point__traits.hpp"
#include "livox_ros_driver2/msg/detail/custom_point__type_support.hpp"

#endif  // LIVOX_ROS_DRIVER2__MSG__CUSTOM_POINT_HPP_
