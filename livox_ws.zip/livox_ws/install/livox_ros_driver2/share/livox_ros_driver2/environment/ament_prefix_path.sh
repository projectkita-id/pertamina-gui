# copied from
# ament_cmake_core/cmake/environment_hooks/environment/ament_prefix_path.sh

ament_prepend_unique_value AMENT_PREFIX_PATH "$AMENT_CURRENT_PREFIX"
